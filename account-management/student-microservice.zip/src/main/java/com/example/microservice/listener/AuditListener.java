package com.example.microservice.listener;

import com.example.microservice.entity.Student;
import jakarta.persistence.PrePersist;

import java.time.LocalDateTime;

public class AuditListener {

    @PrePersist
    public void beforeSave(Student student) {
        student.setCreatedAt(LocalDateTime.now());
    }
}
