package com.example.microservice.service;

import com.example.microservice.dto.StudentDTO;
import com.example.microservice.entity.Student;

import java.util.List;

public interface StudentService {
    Student save(StudentDTO dto);
    List<Student> getAll();
}
