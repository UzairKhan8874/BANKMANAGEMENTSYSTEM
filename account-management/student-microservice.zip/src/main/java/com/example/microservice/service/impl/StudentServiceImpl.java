package com.example.microservice.service.impl;

import com.example.microservice.dto.StudentDTO;
import com.example.microservice.entity.Student;
import com.example.microservice.repository.StudentRepository;
import com.example.microservice.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository repository;

    @Override
    public Student save(StudentDTO dto) {
        Student s = new Student();
        s.setName(dto.getName());
        s.setEmail(dto.getEmail());
        return repository.save(s);
    }

    @Override
    public List<Student> getAll() {
        return repository.findAll();
    }
}
