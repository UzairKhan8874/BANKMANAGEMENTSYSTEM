package com.account.controller;

import com.account.dto.AccountRequestDTO;
import com.account.response.ApiResponse;
import com.account.service.AccountService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService service;

    public AccountController(AccountService service) {
        this.service = service;
    }

    @PostMapping
    public ApiResponse<?> create(@Valid @RequestBody AccountRequestDTO dto) {
        return new ApiResponse<>(true, "Account created", service.save(dto));
    }

    @GetMapping
    public ApiResponse<?> getAll() {
        return new ApiResponse<>(true, "All accounts", service.getAll());
    }
}